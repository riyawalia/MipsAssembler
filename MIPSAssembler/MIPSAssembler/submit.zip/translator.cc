//
//  translator.cpp
//  MIPSAssembler
//
//  Created by Riya Walia on 2018-05-26.
//  Copyright © 2018 Riya Walia. All rights reserved.
//

#include "translator.h"
